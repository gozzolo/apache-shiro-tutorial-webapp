'''
from selenium import webdriver
#"browser = webdriver.Ie()"
PROXY = "127.0.0.1:3128"
desired_capabilities = webdriver.DesiredCapabilities.INTERNETEXPLORER.copy()
desired_capabilities['proxy'] = {
    "httpProxy":PROXY,
    "ftpProxy":PROXY,
    "sslProxy":PROXY,
    "noProxy":None,
    "proxyType":"MANUAL",
    "class":"org.openqa.selenium.Proxy",
    "autodetect":False
}

# you have to use remote, otherwise you'll have to code it yourself in python to 
# dynamically changing the system proxy preferences
driver = webdriver.Remote("http://localhost:5555", desired_capabilities)
#browser = webdriver.Remote(command_executor='http://127.0.0.1:5555', desired_capabilities=DesiredCapabilities.INTERNETEXPLORER)
driver.get('http://seleniumhq.org/')
'''
import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

class PythonOrgSearch(unittest.TestCase):

	def setUp(self):
		PROXY = "127.0.0.1:3128"
		desired_capabilities = webdriver.DesiredCapabilities.INTERNETEXPLORER.copy()
		desired_capabilities['proxy'] = {
		"httpProxy":PROXY,
		"ftpProxy":PROXY,
		"sslProxy":PROXY,
		"noProxy":None,
		"proxyType":"MANUAL",
		"class":"org.openqa.selenium.Proxy",
		"autodetect":False
		}
		self.driver = webdriver.Remote("http://localhost:5555", desired_capabilities)
		
	def test_search_in_python_org(self):
		driver = self.driver
		driver.implicitly_wait(10)
		driver.get("https://aispp.axa-italia.it")
		self.assertIn("Accesso a AIS", driver.title)
		elem = driver.find_element_by_name("USER")
		elem.send_keys("ag1001")
		elem = driver.find_element_by_name("PASSWORD")
		elem.send_keys("Password01")
		elem.send_keys(Keys.RETURN)
		
		#elem.find_element_by_partial_link_text('')
		
		#elem.find_element(By.XPATH, '//button[text()="Accedi aAOL CIF IOL QOL"]')
		#elem.find_element_by_xpath("/html/body/div/div[3]/table/tbody/tr[1]/td/button")
		#elem.click_go_button()
		
		driver.get("https://axaonlinecollaudo-sso.axa-italia.it/servlet/LoginOperatore?RGICommand=login&amp;RGIResponseOk=/login/Login.html")
		self.assertIn("Axa IAM Start Home Page", driver.title)
		time.sleep(10)
		'''
		assert "No results found." not in driver.page_source
		'''

	def tearDown(self):
		self.driver.close()

if __name__ == "__main__":
    unittest.main()