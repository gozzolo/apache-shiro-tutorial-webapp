  -- commento di test

select * from pippo; -- commento di test

pluto;

select a,
	b,
	c
from pippo
where a='pippo' or b='pippo;pluto';


create table pippo (

	a varchar(20) no null,
	b integer);